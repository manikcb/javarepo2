package com.example.scriptexecutor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ScriptExecutorController {

    @Autowired
    private ScriptExecutorService scriptExecutorService;

    @GetMapping("/")
    public String showHomePage(Model model) {
        model.addAttribute("output", "");
        return "index";
    }

    @PostMapping("/run-script")
    public String runScript(Model model) {
        String output = scriptExecutorService.executeScript("/home/manibandla/script1.sh");
        model.addAttribute("output", output);
        return "index";
    }
}
