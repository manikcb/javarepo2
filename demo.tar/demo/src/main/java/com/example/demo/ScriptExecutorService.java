package com.example.scriptexecutor;

import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.InputStreamReader;

@Service
public class ScriptExecutorService {

    public String executeScript(String scriptPath) {
        StringBuilder output = new StringBuilder();

        try {
            // Initialize ProcessBuilder with the script path
            ProcessBuilder processBuilder = new ProcessBuilder("bash", scriptPath);

            // Start the process
            Process process = processBuilder.start();

            // Capture the script's standard output
            BufferedReader outputReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = outputReader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Capture the script's error output
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            while ((line = errorReader.readLine()) != null) {
                output.append("ERROR: ").append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();
            output.append("\nExit Code: ").append(exitCode);

        } catch (Exception e) {
            output.append("Exception occurred: ").append(e.getMessage());
        }

        return output.toString();
    }
}
