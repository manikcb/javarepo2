package com.example.scriptexecutor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class ScriptExecutorApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ScriptExecutorApplication.class, args);
    }
}
